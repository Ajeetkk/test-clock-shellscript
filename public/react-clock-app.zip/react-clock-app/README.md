# react-clock-app

Simple package to learn how to publish react component into NPM

```javascript
import ReactClockApp from "react-clock-app";
<ReactClockApp />; // Simple print Hello world.
```
